Thank you for using the Craftventure Resourcepack.

All rights reserved. You are allowed to use (parts) of this resourcepack for private usage. You are not allowed to use (parts) of this resourcepack for other usages including but not limited to other servers, other games or websites.

Credit where credit's due:
- "Dive helmet" by Char103
- "Happy New Year 2020 hat" by bappotappo

All of Craftventure's other models featured in this pack are made by:
- Kukamonda
- LordPringlesss
- Mennoo_
- Crafterly
- AncientPixel
- Cubix

This resourcepack also uses some resources from the following sources:
- Google Material Design/material.io (icons, sounds)
- Guild Wars 2 (sounds)
- NoLimits 2 (sounds)
- RollerCoaster Tycoon 2 & 3 (sounds)
- Mario Kart (sounds)
- Portal/Team Fortress 2 (sounds)

Special thanks to Canioxe for fixing several old models!

This resourcepack also includes "NegativeSpaceFont" by AmberWat. For the original source and license see https://github.com/AmberWat/NegativeSpaceFont and https://github.com/AmberWat/NegativeSpaceFont/blob/master/LICENSE.txt

This resourcepack also includes "TinyEmojiFontResource" by AmberWat: https://github.com/AmberWat/TinyEmojiFontResource and https://github.com/AmberWat/TinyEmojiFontResource/blob/main/LICENSE